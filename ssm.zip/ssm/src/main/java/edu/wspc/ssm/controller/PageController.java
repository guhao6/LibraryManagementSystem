package edu.wspc.ssm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PageController {
    // 仅作为备用入口，和BookController不冲突
    @GetMapping("/books")
    public String booksPage() {
        return "redirect:/book"; // 重定向到/book，避免冲突
    }
}