package edu.wspc.ssm.vo;

/**
 * 标签实体类
 * 完全匹配数据库tag表的字段结构
 */
public class Tag {
    // 对应数据库tag表的tag_id字段
    private Integer tagId;
    // 对应数据库tag表的name字段
    private String name;

    // 空参构造器（必须有，Spring和JSP渲染需要）
    public Tag() {
    }

    // 全参构造器（方便快速创建对象）
    public Tag(Integer tagId, String name) {
        this.tagId = tagId;
        this.name = name;
    }

    // tagId的getter方法（JSP页面${tag.tagId}会调用这个方法）
    public Integer getTagId() {
        return tagId;
    }

    // tagId的setter方法（查询数据时给属性赋值）
    public void setTagId(Integer tagId) {
        this.tagId = tagId;
    }

    // name的getter方法（JSP页面${tag.name}会调用这个方法）
    public String getName() {
        return name;
    }

    // name的setter方法（查询数据时给属性赋值）
    public void setName(String name) {
        this.name = name;
    }

    // 重写toString方法（方便控制台打印标签信息，调试用）
    @Override
    public String toString() {
        return "Tag{" +
                "tagId=" + tagId +
                ", name='" + name + '\'' +
                '}';
    }
}