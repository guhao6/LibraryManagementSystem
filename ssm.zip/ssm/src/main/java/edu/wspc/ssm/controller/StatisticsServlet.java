package edu.wspc.ssm.controller;

import edu.wspc.ssm.tools.DBUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/statistics")
public class StatisticsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            // 1. 获取借阅 Top 10 图书
            List<Map<String, Object>> topBooks = getTopBorrowedBooks(10);

            // 2. 获取当前未归还数量
            int currentBorrowCount = getCurrentBorrowCount();

            // 3. 获取逾期未还数量
            int overdueCount = getOverdueCount();

            // 设置到 request
            req.setAttribute("topBooks", topBooks);
            req.setAttribute("currentBorrowCount", currentBorrowCount);
            req.setAttribute("overdueCount", overdueCount);

            // 转发到 JSP
            req.getRequestDispatcher("/statistics.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "加载统计数据失败：" + e.getMessage());
            req.getRequestDispatcher("/statistics.jsp").forward(req, resp);
        }
    }

    // 查询借阅次数 Top N 的图书
    private List<Map<String, Object>> getTopBorrowedBooks(int limit) throws SQLException {
        String sql = """
            SELECT 
                b.title,
                b.author,
                COUNT(*) AS borrow_count
            FROM borrow_record br
            JOIN book b ON br.book_id = b.book_id
            WHERE br.is_deleted = 0 
              AND b.is_deleted = 0
            GROUP BY b.book_id, b.title, b.author
            ORDER BY borrow_count DESC
            LIMIT ?
            """;

        List<Map<String, Object>> list = new ArrayList<>();
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Map<String, Object> book = new HashMap<>();
                book.put("title", rs.getString("title"));
                book.put("author", rs.getString("author"));
                book.put("borrowCount", rs.getInt("borrow_count"));
                list.add(book);
            }
        }
        return list;
    }

    // 查询当前未归还的借阅记录数（status = 'borrowed'）
    private int getCurrentBorrowCount() throws SQLException {
        String sql = """
            SELECT COUNT(*) 
            FROM borrow_record 
            WHERE is_deleted = 0 AND status = 'borrowed'
            """;
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // 查询逾期未还的记录数（status = 'overdue'）
    private int getOverdueCount() throws SQLException {
        String sql = """
            SELECT COUNT(*) 
            FROM borrow_record 
            WHERE is_deleted = 0 AND status = 'overdue'
            """;
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }
}