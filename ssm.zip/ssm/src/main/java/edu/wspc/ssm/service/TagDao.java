package edu.wspc.ssm.service;

// 正确导包

import edu.wspc.ssm.tools.DBListener2;
import edu.wspc.ssm.vo.Tag;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository // 推荐用于 DAO 层
public class TagDao extends DBListener2 {

    public void addTag(String tagName) {
        String sql = "INSERT INTO tag(name) VALUES (?)";
        executeUpdate(sql, tagName);
    }

    public void updateTag(Integer tagId, String newName) {
        String sql = "UPDATE tag SET name = ? WHERE tag_id = ?";
        executeUpdate(sql, newName, tagId);
    }

    public void deleteTag(Integer tagId) {
        String sql = "DELETE FROM tag WHERE tag_id = ?";
        executeUpdate(sql, tagId);
    }

    public void bindBookTag(Integer bookId, Integer tagId) {
        String sql = "INSERT INTO book_tag(book_id, tag_id) VALUES (?, ?)";
        executeUpdate(sql, bookId, tagId);
    }

    public void unbindBookTag(Integer bookId, Integer tagId) {
        String sql = "DELETE FROM book_tag WHERE book_id = ? AND tag_id = ?";
        executeUpdate(sql, bookId, tagId);
    }

    public List<Tag> getAllTags() {
        List<Tag> tagList = new ArrayList<>();
        String sql = "SELECT tag_id, name FROM tag";
        ResultSet rs = executeQuery(sql);
        try {
            while (rs.next()) {
                Tag tag = new Tag();
                tag.setTagId(rs.getInt("tag_id"));
                tag.setName(rs.getString("name"));
                tagList.add(tag);
            }
        } catch (SQLException e) {
            System.err.println("查询所有标签失败：" + e.getMessage());
        } finally {
            close(null, null, rs);
        }
        return tagList;
    }

    public List<Tag> getTagsByBookId(Integer bookId) {
        List<Tag> tagList = new ArrayList<>();
        String sql = "SELECT t.tag_id, t.name FROM tag t " +
                "JOIN book_tag bt ON t.tag_id = bt.tag_id " +
                "WHERE bt.book_id = ?";
        ResultSet rs = executeQuery(sql, bookId);
        try {
            while (rs.next()) {
                Tag tag = new Tag();
                tag.setTagId(rs.getInt("tag_id"));
                tag.setName(rs.getString("name"));
                tagList.add(tag);
            }
        } catch (SQLException e) {
            System.err.println("查询图书标签失败：" + e.getMessage());
        } finally {
            close(null, null, rs);
        }
        return tagList;
    }

    public Tag getTagById(Integer tagId) {
        Tag tag = null;
        String sql = "SELECT tag_id, name FROM tag WHERE tag_id = ?";
        ResultSet rs = executeQuery(sql, tagId);
        try {
            if (rs.next()) {
                tag = new Tag();
                tag.setTagId(rs.getInt("tag_id"));
                tag.setName(rs.getString("name"));
            }
        } catch (SQLException e) {
            System.err.println("查询标签详情失败：" + e.getMessage());
        } finally {
            close(null, null, rs);
        }
        return tag;
    }
}