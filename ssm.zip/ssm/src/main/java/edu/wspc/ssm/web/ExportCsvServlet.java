package edu.wspc.ssm.web;

import edu.wspc.ssm.service.StatisticsService;
import jakarta.inject.Inject;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/api/statistics/export-csv")
public class ExportCsvServlet extends HttpServlet {

    @Inject
    private StatisticsService statisticsService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/csv;charset=UTF-8");
        resp.setHeader("Content-Disposition", "attachment; filename=\"borrow_statistics.csv\"");

        String csv = statisticsService.generateCsvContent();
        resp.getWriter().write(csv);
    }
}