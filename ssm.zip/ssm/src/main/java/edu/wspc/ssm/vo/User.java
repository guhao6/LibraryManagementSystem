package edu.wspc.ssm.vo;

import java.util.Date;

// 纯基础Java语法，无任何注解，手动实现get/set
public class User {
    private Integer userId;       // 用户ID
    private String username;      // 用户名
    private String studentId;     // 学号
    private String phone;         // 手机号
    private String email;         // 邮箱
    private Date createdAt;       // 创建时间
    private Date updatedAt;       // 更新时间
    private Integer isDeleted;    // 是否删除（0-未删，1-已删）

    // userId的get/set
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    // username的get/set
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    // studentId的get/set
    public String getStudentId() {
        return studentId;
    }
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    // phone的get/set
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }

    // email的get/set
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    // createdAt的get/set
    public Date getCreatedAt() {
        return createdAt;
    }
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    // updatedAt的get/set
    public Date getUpdatedAt() {
        return updatedAt;
    }
    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    // isDeleted的get/set
    public Integer getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }
}