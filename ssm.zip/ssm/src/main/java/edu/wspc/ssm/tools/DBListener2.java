package edu.wspc.ssm.tools;

import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

import java.sql.*;

@WebListener
public class DBListener2 implements ServletContextListener {
    // 适配新数据库 library_system
    private static final String DB_URL = "jdbc:mysql://localhost:3306/library_system?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root"; // 替换为你的数据库用户名
    private static final String DB_PWD = "123456"; // 替换为你的数据库密码
    private static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        try {
            Class.forName(DB_DRIVER);
            System.out.println("数据库驱动加载成功！");
        } catch (ClassNotFoundException e) {
            System.err.println("驱动加载失败：" + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {}

    public Connection getConnection() {
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PWD);
        } catch (SQLException e) {
            System.err.println("获取连接失败：" + e.getMessage());
            throw new RuntimeException(e);
        }
        return conn;
    }

    public void executeUpdate(String sql, Object... params) {
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            setParams(pstmt, params);
            pstmt.executeUpdate();
            System.out.println("SQL执行成功：" + sql);
        } catch (SQLException e) {
            System.err.println("SQL执行失败：" + e.getMessage());
            // 抛出运行时异常，让上层Service捕获
            throw new RuntimeException("数据库操作失败：" + e.getMessage());
        }
    }

    public ResultSet executeQuery(String sql, Object... params) {
        try {
            Connection conn = getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            setParams(pstmt, params);
            return pstmt.executeQuery();
        } catch (SQLException e) {
            System.err.println("查询失败：" + e.getMessage());
            throw new RuntimeException(e);
        }
    }

    private void setParams(PreparedStatement pstmt, Object... params) throws SQLException {
        if (params != null && params.length > 0) {
            for (int i = 0; i < params.length; i++) {
                pstmt.setObject(i + 1, params[i]);
            }
        }
    }

    public void close(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            System.err.println("关闭资源失败：" + e.getMessage());
        }
    }
}