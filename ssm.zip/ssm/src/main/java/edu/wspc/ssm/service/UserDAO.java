// edu/wspc/ssm/dao/UserDAO.java
package edu.wspc.ssm.service;

import edu.wspc.ssm.tools.DBUtil;
import edu.wspc.ssm.vo.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    // 查询所有未删除用户
    public List<User> findAll() throws SQLException {
        List<User> users = new ArrayList<>();
        String sql = "SELECT user_id, username, student_id, phone, email, created_at, updated_at, is_deleted " +
                "FROM user WHERE is_deleted = 0 ORDER BY user_id";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                User user = mapResultSetToUser(rs);
                users.add(user);
            }
        }
        return users;
    }

    // 根据 ID 查询（仅未删除的）
    public User findById(int userId) throws SQLException {
        String sql = "SELECT user_id, username, student_id, phone, email, created_at, updated_at, is_deleted " +
                "FROM user WHERE user_id = ? AND is_deleted = 0";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUser(rs);
                }
            }
        }
        return null;
    }

    // 插入新用户
    public void insert(User user) throws SQLException {
        String sql = "INSERT INTO user (username, student_id, phone, email, created_at, updated_at, is_deleted) " +
                "VALUES (?, ?, ?, ?, NOW(), NOW(), 0)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getStudentId());
            stmt.setString(3, user.getPhone());
            stmt.setString(4, user.getEmail());
            stmt.executeUpdate();

            try (ResultSet generatedKeys = stmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setUserId(generatedKeys.getInt(1));
                }
            }
        }
    }

    // 更新用户
    public void update(User user) throws SQLException {
        String sql = "UPDATE user SET username = ?, student_id = ?, phone = ?, email = ?, updated_at = NOW() " +
                "WHERE user_id = ? AND is_deleted = 0";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getStudentId());
            stmt.setString(3, user.getPhone());
            stmt.setString(4, user.getEmail());
            stmt.setInt(5, user.getUserId());
            stmt.executeUpdate();
        }
    }

    // 逻辑删除（软删除）
    public void delete(int userId) throws SQLException {
        String sql = "UPDATE user SET is_deleted = 1, updated_at = NOW() WHERE user_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.executeUpdate();
        }
    }

    // 辅助方法：ResultSet → User
    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setUsername(rs.getString("username"));
        user.setStudentId(rs.getString("student_id"));
        user.setPhone(rs.getString("phone"));
        user.setEmail(rs.getString("email"));
        user.setCreatedAt(rs.getTimestamp("created_at"));
        user.setUpdatedAt(rs.getTimestamp("updated_at"));
        user.setIsDeleted(rs.getInt("is_deleted"));
        return user;
    }

    // 在 UserDAO.java 中添加
    public List<User> findByKeyword(String keyword) throws SQLException {
        List<User> users = new ArrayList<>();
        // 模糊匹配 username 或 student_id
        String sql = "SELECT user_id, username, student_id, phone, email, created_at, updated_at, is_deleted " +
                "FROM user " +
                "WHERE is_deleted = 0 " +
                "AND (username LIKE ? OR student_id LIKE ?) " +
                "ORDER BY user_id";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            String likePattern = "%" + keyword + "%";
            stmt.setString(1, likePattern);
            stmt.setString(2, likePattern);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    users.add(mapResultSetToUser(rs));
                }
            }
        }
        return users;
    }


}