package edu.wspc.ssm.web;

import edu.wspc.ssm.service.StatisticsService;
import jakarta.annotation.sql.DataSourceDefinition;
import jakarta.inject.Inject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.List;
import java.util.Map; // ✅ 正确导入 Map

// 定义数据源（开发阶段简单方式）
@DataSourceDefinition(
        name = "java:comp/env/jdbc/LibraryDB",
        className = "com.mysql.cj.jdbc.MysqlDataSource",
        url = "jdbc:mysql://localhost:3306/library_system?useSSL=false&serverTimezone=UTC",
        user = "root",
        password = "123456"
)
@WebServlet("/api/statistics/top-books")
public class StatisticsServlet extends HttpServlet {

    @Autowired
    private StatisticsService statisticsService;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("application/json; charset=UTF-8");

        // ✅ 返回 List<Map<String, Object>>
        List<Map<String, Object>> books = statisticsService.getTopBorrowedBooks(10);

        // ✅ 使用正确的变量名 'books'
        String json = new Gson().toJson(books);
        resp.getWriter().write(json);
    }
}