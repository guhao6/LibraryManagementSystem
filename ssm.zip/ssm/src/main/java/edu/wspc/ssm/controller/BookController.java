package edu.wspc.ssm.controller;

import edu.wspc.ssm.tools.DBListener3;
import edu.wspc.ssm.vo.Book;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Controller
public class BookController {
    private final DBListener3 db = new DBListener3();

    // 首页/查询图书列表（用HttpServletRequest接收参数，避免参数名问题）
    @GetMapping("/book")
    public String queryBooks(HttpServletRequest request, Model model) {
        // 从request获取参数，兼容所有环境
        String title = request.getParameter("title");
        String category = request.getParameter("category");

        Connection conn = db.getConnection();
        List<Book> bookList = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT book_id, isbn, title, author, category, description, " +
                "total_copies as totalCopies, available_copies as availableCopies, status, is_deleted as isDeleted " +
                "FROM book WHERE is_deleted=0");
        List<Object> params = new ArrayList<>();

        // 筛选条件
        if (title != null && !title.isEmpty()) {
            sql.append(" AND title LIKE ?");
            params.add("%" + title + "%");
        }
        if (category != null && !category.isEmpty()) {
            sql.append(" AND category = ?");
            params.add(category);
        }

        try (PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("book_id"));
                book.setIsbn(rs.getString("isbn"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setCategory(rs.getString("category"));
                book.setDescription(rs.getString("description"));
                book.setTotalCopies(rs.getInt("totalCopies"));
                book.setAvailableCopies(rs.getInt("availableCopies"));
                bookList.add(book);
            }
            model.addAttribute("bookList", bookList);
        } catch (SQLException e) {
            model.addAttribute("errorMsg", "查询失败😭：" + e.getMessage());
            e.printStackTrace();
        } finally {
            db.close(conn);
        }
        return "books"; // 跳转到books.jsp
    }

    // 新增图书（用HttpServletRequest接收所有参数）
    @PostMapping("/book/add")
    public String addBook(HttpServletRequest request, Model model) {
        // 从request获取参数，避免参数名反射问题
        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String category = request.getParameter("category");
        String description = request.getParameter("description");
        int totalCopies = Integer.parseInt(request.getParameter("totalCopies"));
        int availableCopies = Integer.parseInt(request.getParameter("availableCopies"));

        Connection conn = db.getConnection();
        try {
            String sql = "INSERT INTO book(isbn, title, author, category, description, total_copies, available_copies, status, is_deleted) " +
                    "VALUES (?,?,?,?,?,?,?,'available',0)";
            db.executeUpdate(conn, sql, isbn, title, author, category, description, totalCopies, availableCopies);
            return "redirect:/book"; // 新增后返回列表
        } catch (Exception e) {
            model.addAttribute("errorMsg", "新增失败🥺：" + e.getMessage());
            e.printStackTrace();
            // 回显数据
            Book book = new Book();
            book.setIsbn(isbn);
            book.setTitle(title);
            book.setAuthor(author);
            book.setCategory(category);
            book.setDescription(description);
            book.setTotalCopies(totalCopies);
            book.setAvailableCopies(availableCopies);
            model.addAttribute("book", book);
            return queryBooks(request, model); // 回到列表页
        } finally {
            db.close(conn);
        }
    }

    // 编辑图书（回显数据，指定@RequestParam的name属性）
    @GetMapping("/book/edit")
    public String editBook(@RequestParam(name = "bookId") int bookId, Model model, HttpServletRequest request) {
        Connection conn = db.getConnection();
        Book book = null;
        try {
            String sql = "SELECT book_id, isbn, title, author, category, description, " +
                    "total_copies as totalCopies, available_copies as availableCopies " +
                    "FROM book WHERE book_id=? AND is_deleted=0";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, bookId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                book = new Book();
                book.setId(rs.getInt("book_id"));
                book.setIsbn(rs.getString("isbn"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setCategory(rs.getString("category"));
                book.setDescription(rs.getString("description"));
                book.setTotalCopies(rs.getInt("totalCopies"));
                book.setAvailableCopies(rs.getInt("availableCopies"));
            }
            model.addAttribute("book", book);
            // 同时查询列表数据，保证页面完整
            queryBooks(request, model);
        } catch (SQLException e) {
            model.addAttribute("errorMsg", "加载编辑数据失败😭：" + e.getMessage());
            e.printStackTrace();
        } finally {
            db.close(conn);
        }
        return "books";
    }

    // 修改图书（用request接收参数）
    @PostMapping("/book/update")
    public String updateBook(HttpServletRequest request, Model model) {
        int bookId = Integer.parseInt(request.getParameter("bookId"));
        String isbn = request.getParameter("isbn");
        String title = request.getParameter("title");
        String author = request.getParameter("author");
        String category = request.getParameter("category");
        String description = request.getParameter("description");
        int totalCopies = Integer.parseInt(request.getParameter("totalCopies"));
        int availableCopies = Integer.parseInt(request.getParameter("availableCopies"));

        Connection conn = db.getConnection();
        try {
            String sql = "UPDATE book SET isbn=?, title=?, author=?, category=?, description=?, " +
                    "total_copies=?, available_copies=? WHERE book_id=?";
            db.executeUpdate(conn, sql, isbn, title, author, category, description, totalCopies, availableCopies, bookId);
            return "redirect:/book"; // 修改后返回列表
        } catch (Exception e) {
            model.addAttribute("errorMsg", "修改失败🥺：" + e.getMessage());
            e.printStackTrace();
            // 回显数据
            Book book = new Book();
            book.setId(bookId);
            book.setIsbn(isbn);
            book.setTitle(title);
            book.setAuthor(author);
            book.setCategory(category);
            book.setDescription(description);
            book.setTotalCopies(totalCopies);
            book.setAvailableCopies(availableCopies);
            model.addAttribute("book", book);
            return queryBooks(request, model);
        } finally {
            db.close(conn);
        }
    }

    // 删除图书（指定@RequestParam的name属性）
    @GetMapping("/book/delete")
    public String deleteBook(@RequestParam(name = "bookId") int bookId, Model model, HttpServletRequest request) {
        Connection conn = db.getConnection();
        try {
            String sql = "UPDATE book SET is_deleted=1 WHERE book_id=?";
            db.executeUpdate(conn, sql, bookId);
            return "redirect:/book"; // 删除后返回列表
        } catch (Exception e) {
            model.addAttribute("errorMsg", "删除失败😭：" + e.getMessage());
            e.printStackTrace();
            return queryBooks(request, model);
        } finally {
            db.close(conn);
        }
    }
}