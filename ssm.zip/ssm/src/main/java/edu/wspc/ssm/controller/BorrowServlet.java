// src/main/java/com/yongwubug/servlet/BorrowServlet.java
package edu.wspc.ssm.controller;

import edu.wspc.ssm.tools.DBUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/borrow")
public class BorrowServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if ("list".equals(action)) {
            listBorrowRecords(req, resp);
        } else {
            req.getRequestDispatcher("/borrow.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        try {
            if ("borrow".equals(action)) {
                doBorrow(req, resp);
            } else if ("return".equals(action)) {
                doReturn(req, resp);
            } else if ("delete".equals(action)) {
                deleteRecord(req, resp);  // ✅ 正确
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "操作失败：" + e.getMessage());
            req.getRequestDispatcher("/borrow.jsp").forward(req, resp);
        }
    }

    // 借书
    private void doBorrow(HttpServletRequest req, HttpServletResponse resp) throws SQLException, IOException {
        int userId = Integer.parseInt(req.getParameter("userId"));
        int bookId = Integer.parseInt(req.getParameter("bookId"));

        Connection conn = DBUtil.getConnection();
        conn.setAutoCommit(false);

        try {
            // 检查图书是否可借
            PreparedStatement psCheck = conn.prepareStatement(
                    "SELECT available_copies, status FROM book WHERE book_id = ? AND is_deleted = 0"
            );
            psCheck.setInt(1, bookId);
            ResultSet rs = psCheck.executeQuery();
            if (!rs.next() || rs.getInt("available_copies") <= 0 || !"available".equals(rs.getString("status"))) {
                throw new RuntimeException("该图书不可借阅");
            }

            // 插入借阅记录
            PreparedStatement psInsert = conn.prepareStatement(
                    "INSERT INTO borrow_record (user_id, book_id, borrow_date, status) VALUES (?, ?, NOW(), 'borrowed')"
            );
            psInsert.setInt(1, userId);
            psInsert.setInt(2, bookId);
            psInsert.executeUpdate();

            // 减少可借数量
            PreparedStatement psUpdate = conn.prepareStatement(
                    "UPDATE book SET available_copies = available_copies - 1 WHERE book_id = ?"
            );
            psUpdate.setInt(1, bookId);
            psUpdate.executeUpdate();

            conn.commit();
            resp.sendRedirect("borrow?action=list");
        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }

    // 还书
    private void doReturn(HttpServletRequest req, HttpServletResponse resp) throws SQLException, IOException {
        int recordId = Integer.parseInt(req.getParameter("recordId"));

        Connection conn = DBUtil.getConnection();
        conn.setAutoCommit(false);

        try {
            // 获取借阅记录和图书ID
            PreparedStatement psGet = conn.prepareStatement(
                    "SELECT book_id, borrow_date FROM borrow_record WHERE record_id = ? AND is_deleted = 0"
            );
            psGet.setInt(1, recordId);
            ResultSet rs = psGet.executeQuery();
            if (!rs.next()) throw new RuntimeException("记录不存在");

            int bookId = rs.getInt("book_id");
            Timestamp borrowDate = rs.getTimestamp("borrow_date");
            boolean isOverdue = LocalDateTime.now().minusDays(30).isAfter(borrowDate.toLocalDateTime());

            // 更新借阅记录
            PreparedStatement psUpdateRecord = conn.prepareStatement(
                    "UPDATE borrow_record SET return_date = NOW(), status = ? WHERE record_id = ?"
            );
            psUpdateRecord.setString(1, isOverdue ? "overdue" : "returned");
            psUpdateRecord.setInt(2, recordId);
            psUpdateRecord.executeUpdate();

            // 增加图书库存
            PreparedStatement psUpdateBook = conn.prepareStatement(
                    "UPDATE book SET available_copies = available_copies + 1 WHERE book_id = ?"
            );
            psUpdateBook.setInt(1, bookId);
            psUpdateBook.executeUpdate();

            conn.commit();
            resp.sendRedirect("borrow?action=list");
        } catch (Exception e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }

    // 删除（逻辑删除）
    private void deleteRecord(HttpServletRequest req, HttpServletResponse resp) throws SQLException, IOException {
        int recordId = Integer.parseInt(req.getParameter("recordId"));
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement("UPDATE borrow_record SET is_deleted = 1 WHERE record_id = ?")) {
            ps.setInt(1, recordId);
            ps.executeUpdate();
            resp.sendRedirect("borrow?action=list");
        }
    }

    // 查询借阅记录（用于展示）
    private void listBorrowRecords(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Map<String, Object>> records = new ArrayList<>();
        String keyword = req.getParameter("keyword"); // 支持学号或书名模糊查

        String sql = """
            SELECT 
                br.record_id, br.borrow_date, br.return_date, br.status,
                u.student_id, u.username,
                b.title, b.author
            FROM borrow_record br
            JOIN user u ON br.user_id = u.user_id
            JOIN book b ON br.book_id = b.book_id
            WHERE br.is_deleted = 0
        """;

        if (keyword != null && !keyword.trim().isEmpty()) {
            sql += " AND (u.student_id LIKE ? OR b.title LIKE ?)";
        }
        sql += " ORDER BY br.borrow_date DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            if (keyword != null && !keyword.trim().isEmpty()) {
                String like = "%" + keyword.trim() + "%";
                ps.setString(1, like);
                ps.setString(2, like);
            }

            ResultSet rs = ps.executeQuery();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

            while (rs.next()) {
                Map<String, Object> record = new HashMap<>();
                record.put("recordId", rs.getInt("record_id"));
                record.put("studentId", rs.getString("student_id"));
                record.put("username", rs.getString("username"));
                record.put("bookTitle", rs.getString("title"));
                record.put("author", rs.getString("author"));
                record.put("borrowDate", rs.getTimestamp("borrow_date").toLocalDateTime().format(formatter));
                Timestamp returnTs = rs.getTimestamp("return_date");
                record.put("returnDate", returnTs == null ? "未归还" : returnTs.toLocalDateTime().format(formatter));
                record.put("status", rs.getString("status"));
                records.add(record);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        req.setAttribute("records", records);
        req.setAttribute("keyword", keyword);
        req.getRequestDispatcher("/borrow.jsp").forward(req, resp);
    }
}