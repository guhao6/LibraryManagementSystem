package edu.wspc.ssm.controller;

// 把原来的 import edu.wspc.ssm.entity.Tag;
// 改成
import edu.wspc.ssm.vo.Tag;
import edu.wspc.ssm.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/tag")
public class TagController {

    @Autowired
    private TagService tagService;

    @GetMapping("/list")
    public ModelAndView tagList() {
        ModelAndView mv = new ModelAndView("/list");
        List<Tag> tagList = tagService.getAllTags();
        mv.addObject("tagList", tagList);
        return mv;
    }

    @PostMapping("/add")
    @ResponseBody
    public String addTag(@RequestParam("tagName") String tagName) {
        try {
            tagService.addTag(tagName);
            return "success";
        } catch (Exception e) {
            return "fail：" + e.getMessage();
        }
    }

    @PostMapping("/update")
    @ResponseBody
    public String updateTag(@RequestParam("tagId") Integer tagId,
                            @RequestParam("newName") String newName) {
        try {
            tagService.updateTag(tagId, newName);
            return "success";
        } catch (Exception e) {
            return "fail：" + e.getMessage();
        }
    }

    @GetMapping("/delete")
    @ResponseBody
    public String deleteTag(@RequestParam("tagId") Integer tagId) {
        try {
            tagService.deleteTag(tagId);
            return "success";
        } catch (Exception e) {
            return "fail：" + e.getMessage();
        }
    }

    @PostMapping("/bind")
    @ResponseBody
    public String bindBookTag(@RequestParam("bookId") Integer bookId,
                              @RequestParam("tagId") Integer tagId) {
        try {
            tagService.bindBookTag(bookId, tagId);
            return "success";
        } catch (Exception e) {
            return "fail：" + e.getMessage();
        }
    }

    @GetMapping("/bookTags")
    @ResponseBody
    public List<Tag> getBookTags(@RequestParam("bookId") Integer bookId) {
        return tagService.getTagsByBookId(bookId);
    }
}