package edu.wspc.ssm.service;

import jakarta.annotation.Resource;
import jakarta.enterprise.context.ApplicationScoped;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.*;
import java.util.*;

@ApplicationScoped
public class StatisticsService {

    @Resource(lookup = "java:comp/env/jdbc/LibraryDB")
    private DataSource dataSource;

    public List<Map<String, Object>> getTopBorrowedBooks(int limit) {
        String sql = """
            SELECT 
                b.title,
                COUNT(*) AS borrow_count
            FROM borrow_record br
            JOIN book b ON br.book_id = b.book_id
            WHERE br.is_deleted = 0 
              AND b.is_deleted = 0
            GROUP BY b.book_id, b.title
            ORDER BY borrow_count DESC
            LIMIT ?
            """;

        List<Map<String, Object>> result = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, limit);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Map<String, Object> book = new HashMap<>();
                book.put("title", rs.getString("title"));
                book.put("borrowCount", rs.getInt("borrow_count"));
                result.add(book);
            }
        } catch (SQLException e) {
            throw new RuntimeException("查询借阅统计失败", e);
        }
        return result;
    }

    public String generateCsvContent() {
        String sql = """
            SELECT 
                b.title,
                COUNT(*) AS borrow_count
            FROM borrow_record br
            JOIN book b ON br.book_id = b.book_id
            WHERE br.is_deleted = 0 
              AND b.is_deleted = 0
            GROUP BY b.book_id, b.title
            ORDER BY borrow_count DESC
            """;

        StringBuilder csv = new StringBuilder();
        csv.append("书名,借阅次数\n");

        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String title = rs.getString("title").replace("\"", "\"\""); // 转义双引号
                int count = rs.getInt("borrow_count");
                csv.append("\"").append(title).append("\",").append(count).append("\n");
            }
        } catch (SQLException e) {
            throw new RuntimeException("生成CSV失败", e);
        }
        return csv.toString();
    }
}