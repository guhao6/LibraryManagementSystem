package edu.wspc.ssm.service;

import edu.wspc.ssm.vo.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TagService {

    @Autowired  // 使用依赖注入替代new
    private TagDao tagDao;

    public void addTag(String tagName) {
        if (tagName == null || tagName.trim().isEmpty()) {
            throw new RuntimeException("标签名称不能为空！");
        }
        tagDao.addTag(tagName);
    }

    public void updateTag(Integer tagId, String newName) {
        if (tagId == null || newName == null || newName.trim().isEmpty()) {
            throw new RuntimeException("标签ID和新名称不能为空！");
        }
        tagDao.updateTag(tagId, newName);
    }

    public void deleteTag(Integer tagId) {
        if (tagId == null) {
            throw new RuntimeException("标签ID不能为空！");
        }
        tagDao.deleteTag(tagId);
    }

    public void bindBookTag(Integer bookId, Integer tagId) {
        if (bookId == null || tagId == null) {
            throw new RuntimeException("图书ID和标签ID不能为空！");
        }
        tagDao.bindBookTag(bookId, tagId);
    }

    public void unbindBookTag(Integer bookId, Integer tagId) {
        if (bookId == null || tagId == null) {
            throw new RuntimeException("图书ID和标签ID不能为空！");
        }
        tagDao.unbindBookTag(bookId, tagId);
    }

    public List<Tag> getAllTags() {
        return tagDao.getAllTags();
    }

    // 修正泛型写法
    public List<Tag> getTagsByBookId(Integer bookId) {
        if (bookId == null) {
            throw new RuntimeException("图书ID不能为空！");
        }
        return tagDao.getTagsByBookId(bookId);
    }

    public Tag getTagById(Integer tagId) {
        if (tagId == null) {
            throw new RuntimeException("标签ID不能为空！");
        }
        return tagDao.getTagById(tagId);
    }
}