// edu/wspc/ssm/controller/UserServlet.java
package edu.wspc.ssm.controller;

import edu.wspc.ssm.service.UserDAO;
import edu.wspc.ssm.vo.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/user/*")
public class UserServlet extends HttpServlet {
    private UserDAO userDAO = new UserDAO();

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        String path = req.getPathInfo();
        if (path == null || path.equals("/")) {
            try {
                doList(req, resp);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            return;
        }

        String[] parts = path.split("/");
        String action = parts.length > 1 ? parts[1] : "list";
        String idStr = parts.length > 2 ? parts[2] : "";
        int id = idStr.matches("\\d+") ? Integer.parseInt(idStr) : 0;

        try {
            switch (action) {
                case "list":
                    doList(req, resp);
                    break;
                case "edit":
                    doEdit(req, resp, id);
                    break;
                case "delete":
                    doDelete(req, resp, id);
                    break;
                case "update":
                    doUpdate(req, resp);
                    break;
                case "add":
                    doAdd(req, resp);
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Action not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            req.setAttribute("error", "数据库操作失败: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/jsp/error.jsp").forward(req, resp);
        }
    }

    private void doList(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException, SQLException {
        String keyword = req.getParameter("keyword");
        List<User> userList;
        if (keyword != null && !keyword.trim().isEmpty()) {
            userList = userDAO.findByKeyword(keyword.trim());
        } else {
            userList = userDAO.findAll();
        }
        req.setAttribute("userList", userList);
        req.setAttribute("keyword", keyword); // 用于 JSP 回显
        req.getRequestDispatcher("/WEB-INF/jsp/user.jsp").forward(req, resp);
    }

//    private void doEdit(HttpServletRequest req, HttpServletResponse resp, int id) throws ServletException, IOException, SQLException {
//        User user = (id == 0) ? new User() : userDAO.findById(id);
//        if (id != 0 && user == null) {
//            resp.sendError(HttpServletResponse.SC_NOT_FOUND, "用户不存在");
//            return;
//        }
//        req.setAttribute("user", user);
//        req.getRequestDispatcher("/WEB-INF/jsp/user-edit.jsp").forward(req, resp);
//    }

    private void doEdit(HttpServletRequest req, HttpServletResponse resp, int id)
            throws ServletException, IOException, SQLException {
        User user;
        if (id == 0) {
            user = new User();
            user.setUserId(0); // ✅ 明确设为 0
            user.setUsername("");
            user.setStudentId("");
            user.setPhone("");
            user.setEmail("");
        } else {
            user = userDAO.findById(id);
            if (user == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "用户不存在");
                return;
            }
        }
        req.setAttribute("user", user);
        req.getRequestDispatcher("/WEB-INF/jsp/user-edit.jsp").forward(req, resp);
    }


    private void doDelete(HttpServletRequest req, HttpServletResponse resp, int id) throws IOException, SQLException {
        if (id > 0) {
            userDAO.delete(id);
        }
        resp.sendRedirect(req.getContextPath() + "/user/list");
    }

    private void doUpdate(HttpServletRequest req, HttpServletResponse resp) throws IOException, SQLException {
        int userId = Integer.parseInt(req.getParameter("userId"));
        String username = req.getParameter("username");
        String studentId = req.getParameter("studentId");
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");

        User user = new User();
        user.setUserId(userId);
        user.setUsername(username);
        user.setStudentId(studentId);
        user.setPhone(phone);
        user.setEmail(email);

        userDAO.update(user);
        resp.sendRedirect(req.getContextPath() + "/user/list");
    }

    private void doAdd(HttpServletRequest req, HttpServletResponse resp) throws IOException, SQLException {
        String username = req.getParameter("username");
        String studentId = req.getParameter("studentId");
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");

        User user = new User();
        user.setUsername(username);
        user.setStudentId(studentId);
        user.setPhone(phone);
        user.setEmail(email);

        userDAO.insert(user); // 自动设置 userId
        resp.sendRedirect(req.getContextPath() + "/user/list");
    }
}