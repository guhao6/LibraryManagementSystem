<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>⚙️ 图书管理系统 - 主页面 · 永无Bug队</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        cyber: {
                            primary: '#00ffff',    // 赛博蓝
                            dark: '#0a0e17',       // 深空黑
                            darkLight: '#141b2d',  // 深灰蓝
                        },
                    },
                    fontFamily: {
                        cyber: ['Orbitron', 'Consolas', 'monospace'],
                    },
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            /* 机械网格背景 */
            .bg-cyber-grid {
                background-color: theme('colors.cyber.dark');
                background-image:
                        linear-gradient(rgba(0, 255, 255, 0.1) 1px, transparent 1px),
                        linear-gradient(90deg, rgba(0, 255, 255, 0.1) 1px, transparent 1px);
                background-size: 20px 20px;
            }
            /* 霓虹发光效果 */
            .neon-glow {
                text-shadow: 0 0 5px theme('colors.cyber.primary'),
                0 0 10px theme('colors.cyber.primary');
                box-shadow: 0 0 8px rgba(0, 255, 255, 0.3);
            }
            /* 按钮hover效果 */
            .hover-cyber:hover {
                transform: translateY(-2px);
                box-shadow: 0 0 15px theme('colors.cyber.primary');
            }
        }

        /* 导入机械感字体 */
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&display=swap');
    </style>
</head>
<body class="bg-cyber-grid min-h-screen text-white font-cyber overflow-x-hidden">
<div class="container mx-auto px-4 py-12 max-w-7xl">
    <!-- 顶部标题 -->
    <div class="text-center mb-8">
        <div class="inline-block bg-cyber-darkLight px-8 py-2 rounded-lg mb-2 neon-glow border border-cyber-primary">
            <h1 class="text-2xl font-extrabold text-cyber-primary flex items-center justify-center gap-3">
                <i class="fa fa-microchip"></i>
                <span>图书管理系统</span>
            </h1>
        </div>
        <div class="inline-block bg-cyber-darkLight px-4 py-1 rounded neon-glow border border-cyber-primary text-cyber-primary">
            永无Bug队 <i class="fa fa-bolt"></i>
        </div>
        <p class="mt-3 text-gray-300 text-xs tracking-widest">
            SYSTEM INITIALIZED • EFFICIENT MANAGEMENT • v2.0.7
        </p>
    </div>

    <!-- 功能入口：强制一行展示（5个模块始终在同一行） -->
    <div class="overflow-x-auto pb-4">
        <div class="flex gap-4 justify-center min-w-max">
            <!-- 标签管理 -->
            <a href="${pageContext.request.contextPath}/tag/list" class="group w-40">
                <div class="bg-cyber-darkLight rounded-lg p-3 transform transition-all duration-300 hover-cyber text-center neon-glow border border-cyber-primary h-full">
                    <div class="w-10 h-10 bg-cyber-dark mx-auto rounded-full flex items-center justify-center mb-2 border border-cyber-primary group-hover:bg-cyber-primary/10">
                        <i class="fa fa-tags text-cyber-primary text-lg"></i>
                    </div>
                    <h3 class="text-sm font-semibold text-cyber-primary mb-1">标签管理</h3>
                    <p class="text-gray-400 text-xs tracking-wide">CREATE • EDIT • MANAGE</p>
                </div>
            </a>

            <!-- 图书管理 -->
            <a href="${pageContext.request.contextPath}/books" class="group w-40">
                <div class="bg-cyber-darkLight rounded-lg p-3 transform transition-all duration-300 hover-cyber text-center neon-glow border border-cyber-primary h-full">
                    <div class="w-10 h-10 bg-cyber-dark mx-auto rounded-full flex items-center justify-center mb-2 border border-cyber-primary group-hover:bg-cyber-primary/10">
                        <i class="fa fa-book text-cyber-primary text-lg"></i>
                    </div>
                    <h3 class="text-sm font-semibold text-cyber-primary mb-1">图书管理</h3>
                    <p class="text-gray-400 text-xs tracking-wide">ADD • EDIT • MANAGE</p>
                </div>
            </a>

            <!-- 用户管理 -->
            <a href="${pageContext.request.contextPath}/user/list" class="group w-40">
                <div class="bg-cyber-darkLight rounded-lg p-3 transform transition-all duration-300 hover-cyber text-center neon-glow border border-cyber-primary h-full">
                    <div class="w-10 h-10 bg-cyber-dark mx-auto rounded-full flex items-center justify-center mb-2 border border-cyber-primary group-hover:bg-cyber-primary/10">
                        <i class="fa fa-users text-cyber-primary text-lg"></i>
                    </div>
                    <h3 class="text-sm font-semibold text-cyber-primary mb-1">用户管理</h3>
                    <p class="text-gray-400 text-xs tracking-wide">MANAGE • USER • INFO</p>
                </div>
            </a>

            <!-- 借阅管理 -->
            <a href="${pageContext.request.contextPath}/borrow" class="group w-40">
                <div class="bg-cyber-darkLight rounded-lg p-3 transform transition-all duration-300 hover-cyber text-center neon-glow border border-cyber-primary h-full">
                    <div class="w-10 h-10 bg-cyber-dark mx-auto rounded-full flex items-center justify-center mb-2 border border-cyber-primary group-hover:bg-cyber-primary/10">
                        <i class="fa fa-exchange text-cyber-primary text-lg"></i>
                    </div>
                    <h3 class="text-sm font-semibold text-cyber-primary mb-1">借阅管理</h3>
                    <p class="text-gray-400 text-xs tracking-wide">TRACK • BORROW • RETURN</p>
                </div>
            </a>

            <!-- 借阅统计 -->
            <a href="${pageContext.request.contextPath}/statistics" class="group w-40">
                <div class="bg-cyber-darkLight rounded-lg p-3 transform transition-all duration-300 hover-cyber text-center neon-glow border border-cyber-primary h-full">
                    <div class="w-10 h-10 bg-cyber-dark mx-auto rounded-full flex items-center justify-center mb-2 border border-cyber-primary group-hover:bg-cyber-primary/10">
                        <i class="fas fa-chart-bar text-cyber-primary text-lg"></i>
                    </div>
                    <h3 class="text-sm font-semibold text-cyber-primary mb-1">借阅统计</h3>
                    <p class="text-gray-400 text-xs tracking-wide">ANALYZE • STATISTICS</p>
                </div>
            </a>
        </div>
    </div>

    <!-- 底部信息 -->
    <div class="mt-10 text-center text-gray-500 text-xs tracking-widest">
        <div class="inline-block border border-gray-700 px-3 py-1 rounded">
            <p>© 2026 永无Bug队 • ALL RIGHTS RESERVED • SYSTEM STATUS: <span class="text-cyber-primary">OPERATIONAL</span></p>
        </div>
    </div>
</div>
</body>
</html>