<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>图书管理系统-所有书 ✨</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Microsoft Yahei", "幼圆", sans-serif;
        }
        body {
            background-color: #fff0f5;
            color: #333;
            padding: 40px;
            max-width: 1000px;
            margin: 0 auto;
        }
        /* 新增：顶部头部样式（团队标识+返回按钮） */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 0 10px;
        }
        .team-label {
            color: #ff69b4;
            font-size: 16px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .team-label::before {
            content: "🏆";
            font-size: 18px;
        }
        .home-btn {
            background: linear-gradient(120deg, #ffc0cb, #ff69b4);
            border: none;
            color: white;
            border-radius: 50px;
            padding: 10px 25px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 10px rgba(255, 182, 193, 0.3);
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .home-btn:hover {
            background: linear-gradient(120deg, #ff69b4, #ff85a1);
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 8px 15px rgba(255, 105, 180, 0.3);
        }
        h1 {
            color: #ff69b4;
            margin-bottom: 40px;
            font-size: 36px;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        h1::before, h1::after {
            content: "📚";
            font-size: 40px;
            transform: rotate(10deg);
        }
        h3 {
            color: #ff85a1;
            margin: 0 0 20px 10px;
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        h3::before {
            content: "💖";
            font-size: 22px;
            transform: rotate(15deg);
        }
        .error-msg {
            background: #ffeeee;
            color: #ff4d88;
            padding: 15px;
            border-radius: 20px;
            border: 2px solid #ff99bb;
            margin-bottom: 20px;
            text-align: center;
            font-size: 16px;
        }
        .form-card, .list-card {
            background: #fff;
            padding: 35px;
            border-radius: 25px;
            box-shadow: 0 8px 20px rgba(255, 182, 193, 0.25);
            border: 3px solid #ffd1dc;
            margin-bottom: 30px;
        }
        hr {
            border: none;
            height: 2px;
            background: linear-gradient(90deg, transparent, #ffd1dc, transparent);
            margin: 30px 0;
        }
        input[type="text"], input[type="number"], input[type="hidden"] {
            width: 100%;
            height: 50px;
            border-radius: 50px;
            border: 2px solid #ffd1dc;
            padding: 0 20px;
            font-size: 15px;
            margin: 8px 0 18px;
            outline: none;
            transition: all 0.3s ease;
        }
        input:focus {
            border-color: #ff69b4;
            box-shadow: 0 0 10px rgba(255, 105, 180, 0.2);
            transform: scale(1.02);
        }
        form label {
            display: block;
            color: #ff69b4;
            font-weight: 600;
            font-size: 16px;
            margin-left: 15px;
        }
        form label[for="isbn"]::after { content: " 🆔"; }
        form label[for="title"]::after { content: " 📖"; }
        form label[for="author"]::after { content: " ✍️"; }
        form label[for="category"]::after { content: " 🗂️"; }
        form label[for="description"]::after { content: " 💬"; }
        form label[for="totalCopies"]::after { content: " 📦"; }
        form label[for="availableCopies"]::after { content: " 📤"; }
        form label[for="bookId"]::after { content: " 🔑"; }

        .btn {
            background: linear-gradient(120deg, #ffc0cb, #ff69b4);
            border: none;
            color: white;
            border-radius: 50px;
            padding: 10px 25px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 5px 10px rgba(255, 182, 193, 0.3);
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }
        .btn:hover {
            background: linear-gradient(120deg, #ff69b4, #ff85a1);
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 8px 15px rgba(255, 105, 180, 0.3);
        }
        .btn-submit {
            padding: 12px 40px;
            font-size: 16px;
            display: block;
            margin: 20px auto 0;
        }
        .btn-sm {
            padding: 6px 15px;
            font-size: 13px;
            margin: 0 5px;
        }
        .btn-delete {
            background: linear-gradient(120deg, #ff99bb, #ff4d88);
        }
        .btn-delete:hover {
            background: linear-gradient(120deg, #ff4d88, #ff6699);
        }

        .book-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 20px;
            overflow: hidden;
            margin-top: 20px;
        }
        .book-table th {
            background: linear-gradient(120deg, #ffd1dc, #ffc0cb);
            color: #ff69b4;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 15px;
        }
        .book-table td {
            padding: 15px;
            border-bottom: 1px solid #ffe6ee;
        }
        .book-table tr:hover {
            background-color: #fff5f8;
            transform: scale(1.005);
            transition: all 0.2s ease;
        }
        .action-col {
            display: flex;
            gap: 8px;
        }
        .search-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            align-items: flex-end;
        }
        .search-group {
            flex: 1;
            min-width: 200px;
        }
    </style>
</head>
<body>
<!-- 新增：顶部头部 - 团队标识 + 返回主页面按钮 -->


<h1>图书管理系统 - 所有书模块 ✨</h1>

<!-- 错误提示 -->
<c:if test="${not empty errorMsg}">
    <div class="error-msg">${errorMsg}</div>
</c:if>


<div class="page-header">
    <div class="team-label">永无bug队·罗负责</div>
    <a href="/index.jsp" class="home-btn">返回主页面 🏠</a>
</div>

<!-- 新增/编辑表单 -->
<div class="form-card">
    <h3>${empty book ? "新增图书" : "编辑图书"}</h3>
    <form action="${empty book ? '/book/add' : '/book/update'}" method="post">
        <!-- 编辑时传递bookId -->
        <c:if test="${not empty book}">
            <input type="hidden" name="bookId" value="${book.id}">
        </c:if>

        <!-- 编辑时显示ID -->
        <c:if test="${not empty book}">
            <label for="bookId">图书ID</label>
            <input type="text" name="bookId" id="bookId" value="${book.id}" readonly>
        </c:if>

        <label for="isbn">ISBN</label>
        <input type="text" name="isbn" id="isbn" value="${book.isbn}" required>

        <label for="title">书名</label>
        <input type="text" name="title" id="title" value="${book.title}" required>

        <label for="author">作者</label>
        <input type="text" name="author" id="author" value="${book.author}" required>

        <label for="category">分类</label>
        <input type="text" name="category" id="category" value="${book.category}" required>

        <label for="description">描述</label>
        <input type="text" name="description" id="description" value="${book.description}">

        <label for="totalCopies">总库存</label>
        <input type="number" name="totalCopies" id="totalCopies" value="${book.totalCopies}" min="0" required>

        <label for="availableCopies">可借数量</label>
        <input type="number" name="availableCopies" id="availableCopies" value="${book.availableCopies}" min="0" required>

        <button type="submit" class="btn btn-submit">
            ${empty book ? "新增图书 📖" : "保存修改 ✨"}
        </button>
    </form>
</div>

<hr>

<!-- 图书列表 + 查询 -->
<div class="list-card">
    <h3>图书列表查询 🔍</h3>

    <!-- 查询表单 -->
    <form action="/book" method="get" class="search-form">
        <div class="search-row">
            <div class="search-group">
                <label for="query-title">书名</label>
                <input type="text" name="title" id="query-title" value="${param.title}">
            </div>
            <div class="search-group">
                <label for="query-category">分类</label>
                <input type="text" name="category" id="query-category" value="${param.category}">
            </div>
            <div class="search-group" style="flex: none;">
                <button type="submit" class="btn" style="margin-bottom: 18px;">查询图书 🔍</button>
                <a href="/book" class="btn" style="margin-bottom: 18px;">清空查询 🧹</a>
            </div>
        </div>
    </form>

    <!-- 图书列表 -->
    <table class="book-table">
        <thead>
        <tr>
            <th>ID 🔑</th>
            <th>ISBN 🆔</th>
            <th>书名 📖</th>
            <th>作者 ✍️</th>
            <th>分类 🗂️</th>
            <th>总库存 📦</th>
            <th>可借数量 📤</th>
            <th>操作 ✨</th>
        </tr>
        </thead>
        <tbody>
        <c:forEach items="${bookList}" var="book">
            <tr>
                <td>${book.id}</td>
                <td>${book.isbn}</td>
                <td>${book.title}</td>
                <td>${book.author}</td>
                <td>${book.category}</td>
                <td>${book.totalCopies}</td>
                <td>${book.availableCopies}</td>
                <td class="action-col">
                    <a href="/book/edit?bookId=${book.id}" class="btn btn-sm">编辑 ✏️</a>
                    <a href="/book/delete?bookId=${book.id}" class="btn btn-sm btn-delete"
                       onclick="return confirm('确定要删除《${book.title}》吗？😭')">删除 🗑️</a>
                </td>
            </tr>
        </c:forEach>
        <c:if test="${empty bookList}">
            <tr>
                <td colspan="8" style="text-align: center; color: #ff85a1; padding: 30px;">
                    暂无图书数据 📚 快来添加第一本图书吧！
                </td>
            </tr>
        </c:if>
        </tbody>
    </table>
</div>

<script>
    // 表单验证：可借数量 ≤ 总库存
    document.querySelector('.form-card form').addEventListener('submit', function(e) {
        const available = document.getElementById('availableCopies').value;
        const total = document.getElementById('totalCopies').value;
        if (parseInt(available) > parseInt(total)) {
            alert('可借数量不能大于总库存哦 🥺');
            e.preventDefault();
            return false;
        }
    });
</script>
</body>
</html>