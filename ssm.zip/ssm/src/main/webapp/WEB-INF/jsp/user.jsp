<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>用户管理系统 ✨</title>
    <!-- 引入Bootstrap和图标库 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style>
        /* 全局样式 - 浅粉底色+细密小白点波点 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Microsoft Yahei", "幼圆", sans-serif;
        }
        body {
            background-color: #fff0f5; /* 浅粉底色 */
            background-image: radial-gradient(#ffffff 12%, transparent 12%); /* 小白点波点 */
            background-size: 10px 10px; /* 细密小点，匹配示例效果 */
            background-position: 0 0;
            color: #333333;
            margin: 0;
            padding: 20px 0;
            min-height: 100vh;
            position: relative;
        }
        /* 卡片容器 - 超大圆角+粉色软阴影 */
        .card-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            position: relative;
            z-index: 1;
        }
        .user-card {
            background: #ffffff;
            border-radius: 25px;
            box-shadow: 0 8px 20px rgba(255, 182, 193, 0.25);
            padding: 35px;
            border: 3px solid #ffd1dc;
            position: relative;
            z-index: 1;
        }
        /* 页面标题 + 团队标识 + 返回按钮 组合样式 */
        .header-group {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .page-title {
            font-size: 32px;
            font-weight: 700;
            display: flex;
            align-items: center;
            margin: 0;
            color: #ff69b4;
        }
        .page-title i {
            color: #ff69b4;
            margin-right: 12px;
            font-size: 34px;
            transform: rotate(10deg);
        }
        /* 团队负责标识样式 */
        .team-label {
            color: #ff69b4;
            font-size: 18px;
            font-weight: 600;
            margin-right: 15px;
        }
        /* 搜索区域 */
        .search-bar {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }
        .search-input {
            flex: 1;
            max-width: 350px;
            height: 50px;
            border-radius: 50px;
            border: 2px solid #ffd1dc;
            padding: 0 20px;
            font-size: 15px;
            color: #333;
            outline: none;
            transition: all 0.3s ease;
        }
        .search-input:focus {
            border-color: #ff69b4;
            box-shadow: 0 0 10px rgba(255, 105, 180, 0.2);
            transform: scale(1.02);
        }
        /* 按钮样式 - 渐变粉+圆形+hover动效 */
        .btn-custom {
            background: linear-gradient(120deg, #ffc0cb, #ff69b4);
            border: none;
            color: white;
            border-radius: 50px;
            padding: 10px 25px;
            font-size: 15px;
            font-weight: 600;
            transition: all 0.3s ease;
            box-shadow: 0 5px 10px rgba(255, 182, 193, 0.3);
        }
        .btn-custom:hover {
            background: linear-gradient(120deg, #ff69b4, #ff85a1);
            color: white;
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 8px 15px rgba(255, 105, 180, 0.3);
        }
        /* 表格样式 - 粉嫩风格 */
        .user-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 20px;
            overflow: hidden;
            margin-top: 15px;
        }
        .user-table thead {
            background: linear-gradient(120deg, #ffd1dc, #ffc0cb);
        }
        .user-table th, .user-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ffe6ee;
            color: #333;
        }
        .user-table th {
            font-weight: 600;
            font-size: 15px;
            color: #ff69b4;
        }
        .user-table th::after {
            content: "";
        }
        .user-table th:nth-child(1)::after { content: " 🔑"; }
        .user-table th:nth-child(2)::after { content: " 👧"; }
        .user-table th:nth-child(3)::after { content: " 📚"; }
        .user-table th:nth-child(4)::after { content: " 📱"; }
        .user-table th:nth-child(5)::after { content: " ✉️"; }
        .user-table th:nth-child(6)::after { content: " ✨"; }
        .user-table tr:hover {
            background-color: #fff5f8;
            transform: scale(1.005);
            transition: all 0.2s ease;
        }
        /* 操作按钮 - 小尺寸渐变粉 */
        .btn-operate {
            padding: 8px 15px;
            font-size: 14px;
            border-radius: 50px;
            margin-right: 8px;
        }
        .btn-operate:last-child {
            background: linear-gradient(120deg, #ff99bb, #ff4d88);
        }
        /* 空数据提示 - 粉嫩样式 */
        .user-table td[colspan="6"] {
            color: #ff85a1;
            font-size: 16px;
            text-align: center;
            padding: 30px;
        }
    </style>
</head>
<body>
<div class="card-container">
    <div class="user-card">
        <!-- 顶部区域（功能不变） -->
        <div class="header-group">
            <div class="page-title">
                <i class="fa fa-users"></i> 用户管理 💖
            </div>
            <div style="display: flex; align-items: center;">
                <div class="team-label">永无Bug队 · 阿娇负责💖</div>
                <a href="${pageContext.request.contextPath}/" class="btn-custom">
                    <i class="fa fa-home"></i> 返回首页
                </a>
            </div>
        </div>

        <!-- 搜索+添加区域（功能不变） -->
        <div class="d-flex justify-content-between align-items-center">
            <form method="get" action="${pageContext.request.contextPath}/user/list" class="search-bar">
                <input type="text" name="keyword" class="search-input" placeholder="搜索用户名/学号 📖" value="${param.keyword}">
                <button type="submit" class="btn-custom">
                    <i class="fa fa-search"></i> 搜索
                </button>
            </form>
            <a href="${pageContext.request.contextPath}/user/edit/0" class="btn-custom">
                <i class="fa fa-plus"></i> 添加用户
            </a>
        </div>

        <!-- 用户列表表格（功能不变） -->
        <div class="table-responsive">
            <table class="user-table">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>用户名</th>
                    <th>学号</th>
                    <th>手机号</th>
                    <th>邮箱</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                <c:forEach items="${userList}" var="user">
                    <tr>
                        <td>${user.userId}</td>
                        <td>${user.username}</td>
                        <td>${user.studentId}</td>
                        <td>${user.phone}</td>
                        <td>${user.email}</td>
                        <td>
                            <a href="/user/edit/${user.userId}" class="btn-custom btn-operate">
                                <i class="fa fa-pencil"></i> 编辑
                            </a>
                            <a href="/user/delete/${user.userId}" class="btn-custom btn-operate" onclick="return confirm('确定删除该用户吗？😭')">
                                <i class="fa fa-trash"></i> 删除
                            </a>
                        </td>
                    </tr>
                </c:forEach>
                <c:if test="${empty userList}">
                    <tr>
                        <td colspan="6">
                            <i class="fa fa-info-circle"></i> 暂无用户数据 📚 快来添加第一个用户吧！
                        </td>
                    </tr>
                </c:if>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>