<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>${user.userId == 0 ? "添加用户 ✨" : "编辑用户 ✨"}</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <style>
        /* 全局样式 - 浅粉底色+细密小白点波点 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Microsoft Yahei", "幼圆", sans-serif;
        }
        body {
            background-color: #fff0f5;
            background-image: radial-gradient(#ffffff 12%, transparent 12%);
            background-size: 10px 10px;
            background-position: 0 0;
            color: #333333;
            margin: 0;
            padding: 30px 0;
            min-height: 100vh;
            position: relative;
        }
        /* 表单卡片 - 超大圆角+粉色软阴影 */
        .form-card {
            max-width: 600px;
            margin: 0 auto;
            background: #ffffff;
            border-radius: 25px;
            box-shadow: 0 8px 20px rgba(255, 182, 193, 0.25);
            padding: 40px;
            border: 3px solid #ffd1dc;
            position: relative;
            z-index: 1;
        }
        /* 标题 - 玫粉色+萌系emoji */
        .form-title {
            font-size: 30px;
            font-weight: 700;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            color: #ff69b4;
        }
        .form-title i {
            color: #ff69b4;
            margin-right: 12px;
            font-size: 32px;
            transform: rotate(10deg);
        }
        /* 表单样式 */
        .form-group {
            margin-bottom: 25px;
        }
        .form-label {
            font-weight: 600;
            margin-bottom: 10px;
            display: block;
            color: #ff69b4;
            font-size: 16px;
            margin-left: 5px;
        }
        .form-label::after {
            content: "";
        }
        .form-group:nth-child(1) .form-label::after { content: " 👧"; }
        .form-group:nth-child(2) .form-label::after { content: " 📚"; }
        .form-group:nth-child(3) .form-label::after { content: " 📱"; }
        .form-group:nth-child(4) .form-label::after { content: " ✉️"; }

        /* 输入框 - 圆形+浅粉边框 */
        .form-input {
            width: 100%;
            height: 50px;
            border-radius: 50px;
            border: 2px solid #ffd1dc;
            padding: 0 20px;
            font-size: 15px;
            color: #333;
            outline: none;
            transition: all 0.3s ease;
        }
        .form-input:focus {
            border-color: #ff69b4;
            box-shadow: 0 0 10px rgba(255, 105, 180, 0.2);
            transform: scale(1.02);
        }
        /* 按钮样式 - 渐变粉+圆形+hover动效 */
        .btn-custom {
            background: linear-gradient(120deg, #ffc0cb, #ff69b4);
            border: none;
            color: white;
            border-radius: 50px;
            padding: 12px 30px;
            font-size: 16px;
            font-weight: 600;
            margin-right: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 10px rgba(255, 182, 193, 0.3);
        }
        .btn-custom:hover {
            background: linear-gradient(120deg, #ff69b4, #ff85a1);
            color: white;
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 8px 15px rgba(255, 105, 180, 0.3);
        }
        .btn-group {
            margin-top: 30px;
            display: flex;
            justify-content: center;
            gap: 15px;
        }
    </style>
</head>
<body>
<div class="form-card">
    <div class="form-title">
        <i class="fa fa-user"></i> ${user.userId == 0 ? "添加用户" : "编辑用户"} 💖
    </div>

    <!-- 表单功能代码完全保留 -->
    <form action="${user.userId == 0 ? '/user/add' : '/user/update'}" method="post">
        <input type="hidden" name="userId" value="${user.userId}">

        <div class="form-group">
            <label class="form-label">用户名</label>
            <input type="text" name="username" class="form-input" value="${user.username}" required>
        </div>

        <div class="form-group">
            <label class="form-label">学号</label>
            <input type="text" name="studentId" class="form-input" value="${user.studentId}" required>
        </div>

        <div class="form-group">
            <label class="form-label">手机号</label>
            <input type="tel" name="phone" class="form-input" value="${user.phone}" required>
        </div>

        <div class="form-group">
            <label class="form-label">邮箱</label>
            <input type="email" name="email" class="form-input" value="${user.email}" required>
        </div>

        <div class="btn-group">
            <button type="submit" class="btn-custom">
                <i class="fa fa-save"></i> 保存 ✨
            </button>
            <a href="/user/list" class="btn-custom">
                <i class="fa fa-arrow-left"></i> 返回 📤
            </a>
        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>