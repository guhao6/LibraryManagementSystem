<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>🎀 标签管理中心 · 永无Bug队</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome 4.7 (与你的项目一致) -->
    <link href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#db2777', // 醒目玫粉色（保证可读性）
                        secondary: '#ec4899', // 浅玫粉
                        success: '#10b981',  // 清晰的绿色
                        danger: '#ef4444',   // 清晰的红色
                        warning: '#f59e0b',  // 清晰的黄色
                        dark: '#374151',     // 深灰色（保证正文可读性）
                        pink: {
                            50: '#fef7fb',
                            100: '#fdf2f8',
                            200: '#fce7f3',
                            300: '#fbcfe8'
                        }
                    },
                    boxShadow: {
                        'card': '0 8px 24px rgba(219, 39, 119, 0.1)',
                        'hover': '0 12px 28px rgba(219, 39, 119, 0.15)',
                    },
                    borderRadius: {
                        'xl': '1rem',
                        '2xl': '1.5rem',
                        '3xl': '2rem',
                    }
                }
            }
        }
    </script>
    <style type="text/tailwindcss">
        @layer utilities {
            /* 粉色波点背景 - 双层波点更有层次感 */
            .bg-pink-dot {
                background-color: #fef7fb;
                background-image:
                        radial-gradient(#ec4899 0.5px, transparent 0.5px),
                        radial-gradient(#ec4899 0.5px, #fef7fb 0.5px);
                background-size: 20px 20px;
                background-position: 0 0, 10px 10px;
                background-opacity: 0.2;
            }
            .text-gradient-pink {
                background-clip: text;
                -webkit-background-clip: text;
                color: transparent;
                background-image: linear-gradient(135deg, #db2777 0%, #ec4899 100%);
            }
            .scale-hover {
                transition: transform 0.2s ease, box-shadow 0.2s ease;
            }
            .scale-hover:hover {
                transform: scale(1.03);
            }
            .cute-shadow {
                box-shadow: 0 4px 12px rgba(219, 39, 119, 0.08);
            }
            /* 确保输入框/placeholder文字清晰 */
            .text-pink-strong {
                color: #db2777 !important;
            }
            .placeholder-pink::placeholder {
                color: #ec4899 !important;
                opacity: 1;
            }
        }
    </style>
</head>
<body class="bg-pink-dot min-h-screen">
<div class="container mx-auto px-4 py-8">
    <!-- 头部 -->
    <div class="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
        <div class="flex items-start gap-3 flex-col">
            <div class="flex items-center gap-3">
                <a href="${pageContext.request.contextPath}/index.jsp"
                   class="text-primary hover:text-secondary transition-colors p-2 rounded-full hover:bg-primary/5 cute-shadow">
                    <i class="fa fa-arrow-left text-lg"></i>
                </a>
                <h1 class="text-2xl font-bold text-dark flex items-center gap-2">
                    <i class="fa fa-heart text-primary"></i>
                    <span>标签管理</span>
                    <span class="text-gradient-pink">🎀</span>
                </h1>
            </div>
            <div class="text-sm text-primary ml-10 mt-1">永无Bug队 · 林负责💖</div>
        </div>
        <a href="${pageContext.request.contextPath}/index.jsp"
           class="px-4 py-2 bg-white border border-pink-200 rounded-3xl text-sm font-medium text-primary hover:bg-pink-50 transition-colors shadow-card hover:shadow-hover scale-hover cute-shadow">
            <i class="fa fa-home mr-1 text-primary"></i> 返回主页面✨
        </a>
    </div>

    <!-- 添加标签区域 -->
    <div class="bg-white/90 backdrop-blur-sm rounded-3xl shadow-card p-6 mb-8 border border-pink-200 scale-hover cute-shadow">
        <h2 class="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
            <i class="fa fa-star text-primary"></i> 添加新标签💓
        </h2>
        <div class="flex flex-col sm:flex-row gap-4">
            <input
                    type="text"
                    id="tagName"
                    placeholder="输入标签名称（如：科幻、教材）✨"
                    class="flex-1 px-4 py-3 border border-pink-200 rounded-2xl focus:ring-2 focus:ring-primary/40 focus:border-primary outline-none transition-all text-lg text-dark placeholder-pink"
            />
            <button
                    onclick="addTag()"
                    class="px-6 py-3 bg-white border border-pink-200 rounded-2xl font-medium text-[#db2777] hover:bg-pink-50 transition-colors flex items-center justify-center gap-1 scale-hover cute-shadow"
            >
                <span>添加标签</span>
                <span>🎀</span>
            </button>
        </div>
    </div>

    <!-- 新增：查询标签区域 -->
    <div class="bg-white/90 backdrop-blur-sm rounded-3xl shadow-card p-6 mb-8 border border-pink-200 scale-hover cute-shadow">
        <h2 class="text-lg font-semibold text-primary mb-4 flex items-center gap-2">
            <i class="fa fa-search text-primary"></i> 查询标签🔍
        </h2>
        <div class="flex flex-col sm:flex-row gap-4">
            <input
                    type="text"
                    id="searchTagName"
                    placeholder="输入标签名称关键词搜索✨"
                    class="flex-1 px-4 py-3 border border-pink-200 rounded-2xl focus:ring-2 focus:ring-primary/40 focus:border-primary outline-none transition-all text-lg text-dark placeholder-pink"
            />
            <div class="flex gap-4">
                <button
                        onclick="searchTag()"
                        class="px-6 py-3 bg-primary text-white rounded-2xl font-medium hover:opacity-95 transition-colors flex items-center justify-center gap-1 scale-hover cute-shadow">
                    <i class="fa fa-search"></i>
                    <span>搜索标签🔍</span>
                </button>
                <button
                        onclick="resetSearch()"
                        class="px-6 py-3 bg-white border border-pink-200 text-primary rounded-2xl font-medium hover:bg-pink-50 transition-colors flex items-center justify-center gap-1 scale-hover cute-shadow">
                    <i class="fa fa-refresh"></i>
                    <span>重置搜索♻️</span>
                </button>
            </div>
        </div>
    </div>

    <!-- 标签列表 -->
    <div class="bg-white/90 backdrop-blur-sm rounded-3xl shadow-card border border-pink-200 overflow-hidden scale-hover cute-shadow">
        <div class="overflow-x-auto">
            <table class="w-full" id="tagTable">
                <thead>
                <tr class="bg-gradient-to-r from-primary/10 to-pink-100 border-b border-pink-200">
                    <th class="px-6 py-4 text-left text-xs font-medium text-primary uppercase tracking-wider">标签ID✨</th>
                    <th class="px-6 py-4 text-left text-xs font-medium text-primary uppercase tracking-wider">标签名称💖</th>
                    <th class="px-6 py-4 text-left text-xs font-medium text-primary uppercase tracking-wider">操作🎈</th>
                </tr>
                </thead>
                <tbody class="divide-y divide-pink-200" id="tagTableBody">
                <c:forEach items="${tagList}" var="tag">
                    <tr class="hover:bg-pink-50 transition-colors tag-item" data-tag-name="${tag.name}">
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-dark font-medium">${tag.tagId}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-dark">
                            <span class="bg-pink-100 text-primary px-3 py-1 rounded-full cute-shadow font-medium">${tag.name}✨</span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm">
                            <div class="flex gap-2">
                                <input
                                        type="text"
                                        id="newName_${tag.tagId}"
                                        placeholder="新名称💓"
                                        class="px-3 py-2 border border-pink-200 rounded-xl focus:ring-2 focus:ring-warning/40 focus:border-warning outline-none transition-all text-dark placeholder-pink"
                                />
                                <button
                                        onclick="updateTag(${tag.tagId})"
                                        class="px-3 py-2 bg-warning/10 text-warning rounded-xl text-xs font-medium hover:bg-warning/20 transition-colors flex items-center gap-1 scale-hover cute-shadow"
                                >
                                    <i class="fa fa-pencil"></i> 修改🎨
                                </button>
                                <button
                                        onclick="deleteTag(${tag.tagId})"
                                        class="px-3 py-2 bg-danger/10 text-danger rounded-xl text-xs font-medium hover:bg-danger/20 transition-colors flex items-center gap-1 scale-hover cute-shadow"
                                >
                                    <i class="fa fa-trash"></i> 删除🗑️
                                </button>
                            </div>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>

        <!-- 空状态提示 -->
        <div id="emptyState" class="<c:if test='${empty tagList}'>block</c:if> <c:if test='${not empty tagList}'>hidden</c:if> py-12 text-center">
            <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-pink-100 mb-4 cute-shadow">
                <i class="fa fa-gift text-4xl text-primary"></i>
            </div>
            <p class="text-primary text-lg font-medium">暂无标签数据🎁</p>
            <p class="text-secondary mt-2">点击上方按钮添加第一个可爱标签吧💖</p>
        </div>

        <!-- 新增：搜索无结果提示 -->
        <div id="searchEmptyState" class="hidden py-12 text-center">
            <div class="inline-flex items-center justify-center w-20 h-20 rounded-full bg-pink-100 mb-4 cute-shadow">
                <i class="fa fa-search text-4xl text-primary/50"></i>
            </div>
            <p class="text-primary text-lg font-medium">未找到匹配的标签😕</p>
            <p class="text-secondary mt-2">试试其他关键词或重置搜索吧💖</p>
        </div>
    </div>
</div>

<script>
    const BASE_URL = "${pageContext.request.contextPath}";
    // 保存原始标签列表（用于重置搜索）
    let originalTagList = [];

    // 页面加载完成后初始化原始标签列表
    window.onload = function() {
        // 获取所有标签项并保存
        const tagItems = document.querySelectorAll('.tag-item');
        tagItems.forEach(item => {
            originalTagList.push({
                element: item,
                name: item.getAttribute('data-tag-name')
            });
        });
    };

    function addTag() {
        const tagName = document.getElementById("tagName").value.trim();
        if (!tagName) {
            alert("✨ 请输入可爱的标签名称！");
            return;
        }

        fetch(BASE_URL + "/tag/add", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "tagName=" + encodeURIComponent(tagName)
        })
            .then(res => res.text())
            .then(data => {
                if (data === "success") {
                    alert("🎉 标签添加成功啦～💖");
                    location.reload();
                } else {
                    alert("❌ 添加失败：" + data);
                }
            })
            .catch(err => {
                console.error(err);
                alert("🌐 网络错误，请重试～");
            });
    }

    function updateTag(tagId) {
        const newName = document.getElementById("newName_" + tagId).value.trim();
        if (!newName) {
            alert("✨ 请输入新的可爱标签名称！");
            return;
        }

        fetch(BASE_URL + "/tag/update", {
            method: "POST",
            headers: { "Content-Type": "application/x-www-form-urlencoded" },
            body: "tagId=" + tagId + "&newName=" + encodeURIComponent(newName)
        })
            .then(res => res.text())
            .then(data => {
                if (data === "success") {
                    alert("🎉 标签修改成功啦～💖");
                    location.reload();
                } else {
                    alert("❌ 修改失败：" + data);
                }
            })
            .catch(err => {
                console.error(err);
                alert("🌐 网络错误，请重试～");
            });
    }

    function deleteTag(tagId) {
        if (!confirm("⚠️ 确定要删除这个可爱的标签吗？删除后关联的图书标签也会被移除哦～")) {
            return;
        }

        fetch(BASE_URL + "/tag/delete?tagId=" + tagId)
            .then(res => res.text())
            .then(data => {
                if (data === "success") {
                    alert("🎉 标签删除成功啦～💖");
                    location.reload();
                } else {
                    alert("❌ 删除失败：" + data);
                }
            })
            .catch(err => {
                console.error(err);
                alert("🌐 网络错误，请重试～");
            });
    }

    // 新增：搜索标签功能
    function searchTag() {
        const searchKeyword = document.getElementById("searchTagName").value.trim().toLowerCase();
        const tagTableBody = document.getElementById("tagTableBody");
        const emptyState = document.getElementById("emptyState");
        const searchEmptyState = document.getElementById("searchEmptyState");

        // 隐藏所有提示
        emptyState.classList.add('hidden');
        searchEmptyState.classList.add('hidden');

        if (!searchKeyword) {
            alert("✨ 请输入要搜索的标签关键词！");
            return;
        }

        // 过滤标签
        let matchCount = 0;
        originalTagList.forEach(item => {
            const tagName = item.name.toLowerCase();
            if (tagName.includes(searchKeyword)) {
                item.element.classList.remove('hidden');
                matchCount++;
            } else {
                item.element.classList.add('hidden');
            }
        });

        // 显示对应提示
        if (matchCount === 0) {
            searchEmptyState.classList.remove('hidden');
        }
    }

    // 新增：重置搜索功能
    function resetSearch() {
        // 清空搜索框
        document.getElementById("searchTagName").value = "";
        // 显示所有标签
        originalTagList.forEach(item => {
            item.element.classList.remove('hidden');
        });
        // 隐藏搜索无结果提示，恢复原始空状态
        document.getElementById("searchEmptyState").classList.add('hidden');
        const emptyState = document.getElementById("emptyState");
        if (originalTagList.length === 0) {
            emptyState.classList.remove('hidden');
        }
    }
</script>
</body>
</html>