<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎀 图书借阅中心 · 永无Bug队</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            /* 可爱粉色主题配色 */
            --primary: #db2777;      /* 玫粉色（主色） */
            --primary-light: #ec4899;/* 浅玫粉 */
            --primary-bg: #fef7fb;   /* 粉色背景底 */
            --success: #10b981;      /* 清新绿（保留辨识度） */
            --warning: #f59e0b;      /* 奶黄色（保留辨识度） */
            --danger: #ef4444;       /* 珊瑚红（保留辨识度） */
            --dark: #374151;         /* 深灰色（保证文字可读性） */
            --gray: #9ca3af;
            --card-bg: #ffffff;
            --shadow: 0 8px 24px rgba(219, 39, 119, 0.1);
            --shadow-hover: 0 12px 28px rgba(219, 39, 119, 0.15);
            --radius: 20px;          /* 圆润大圆角，增加可爱感 */
            --small-radius: 12px;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --dark: #f8f9fa;
                --primary-bg: #2c1e2e;
                --card-bg: #1e1e2e;
                --gray: #a0a0a0;
                --shadow: 0 4px 12px rgba(0,0,0,0.3);
            }
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            /* 粉色波点渐变背景，和标签页保持一致 */
            background-color: var(--primary-bg);
            background-image:
                    radial-gradient(var(--primary-light) 0.5px, transparent 0.5px),
                    radial-gradient(var(--primary-light) 0.5px, var(--primary-bg) 0.5px);
            background-size: 20px 20px;
            background-position: 0 0, 10px 10px;
            color: var(--dark);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            margin-bottom: 30px;
            padding: 20px 0;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .header-title {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        h1 {
            font-size: 2.5rem;
            /* 粉色渐变文字 */
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-weight: 800;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .subtitle {
            color: var(--primary);
            margin-left: 10px;
            font-size: 1.1rem;
            font-weight: 500;
        }

        .error {
            background: #ffebee;
            color: var(--primary);
            padding: 12px 20px;
            border-radius: var(--small-radius);
            margin-bottom: 24px;
            display: inline-block;
            box-shadow: var(--shadow);
            animation: fadeIn 0.5s ease;
            border-left: 4px solid var(--primary);
        }

        @media (prefers-color-scheme: dark) {
            .error {
                background: #2d1a1a;
                color: #ff8a80;
            }
        }

        .card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            border: 1px solid #fce7f3;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-hover);
        }

        .card h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            color: var(--primary);
            font-size: 1.4rem;
        }

        .form-group {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 15px;
        }

        .form-group label {
            font-weight: 600;
            min-width: 80px;
            display: flex;
            align-items: center;
            color: var(--dark);
        }

        input[type="number"], input[type="text"] {
            flex: 1;
            padding: 12px 15px;
            border: 2px solid #fce7f3;
            border-radius: var(--small-radius);
            font-size: 1rem;
            transition: all 0.3s;
            background: var(--primary-bg);
            color: var(--dark);
        }

        input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(219, 39, 119, 0.1);
        }

        input::placeholder {
            color: var(--primary-light);
            opacity: 0.8;
        }

        /* 按钮统一粉色主题 */
        button {
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: var(--small-radius);
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        button:hover {
            transform: scale(1.03);
            opacity: 0.95;
        }

        /* 功能按钮配色调整（保留辨识度+粉色调和） */
        .btn-return {
            background: linear-gradient(90deg, var(--success), #14b8a6);
        }
        .btn-return:hover {
            background: linear-gradient(90deg, #05c194, #10b981);
        }

        .btn-delete {
            background: linear-gradient(90deg, var(--danger), #f87171);
        }
        .btn-delete:hover {
            background: linear-gradient(90deg, #e03b60, #ef4444);
        }

        .btn-home, .btn-refresh {
            background: white;
            color: var(--primary);
            border: 2px solid #fce7f3;
        }
        .btn-home:hover, .btn-refresh:hover {
            background: var(--primary-bg);
        }

        .btn-statistics {
            background: linear-gradient(90deg, #4cc9f0, #7dd3fc);
            margin-left: 15px;
        }
        .btn-statistics:hover {
            background: linear-gradient(90deg, #38b6f0, #4cc9f0);
        }

        .search-form {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: var(--card-bg);
            border-radius: var(--small-radius);
            overflow: hidden;
        }

        th, td {
            padding: 14px;
            text-align: left;
            border-bottom: 1px solid #fce7f3;
        }

        @media (prefers-color-scheme: dark) {
            th, td {
                border-bottom: 1px solid #333;
            }
        }

        th {
            background: rgba(219, 39, 119, 0.08);
            font-weight: 600;
            color: var(--primary);
        }

        @media (prefers-color-scheme: dark) {
            th {
                background: rgba(219, 39, 119, 0.15);
            }
        }

        tr:hover {
            background: rgba(219, 39, 119, 0.05);
        }

        @media (prefers-color-scheme: dark) {
            tr:hover {
                background: rgba(219, 39, 119, 0.1);
            }
        }

        .status-borrowed {
            color: var(--warning);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .status-overdue {
            color: var(--danger);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .status-returned {
            color: var(--success);
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .actions {
            display: flex;
            gap: 8px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .form-group {
                flex-direction: column;
            }
            th, td {
                padding: 10px 8px;
                font-size: 0.9rem;
            }
            .actions {
                flex-direction: column;
            }
            h1 {
                font-size: 2rem;
            }
            .header-top {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <header>
        <div class="header-top">
            <div class="header-title">
                <h1><i class="fas fa-book-open"></i> 图书借阅管理中心🎀</h1>
                <p class="subtitle">永无Bug队 · 刘负责💖</p>
            </div>
            <a href="index.jsp" style="text-decoration: none;">
                <button class="btn-home">
                    <i class="fas fa-home"></i> 首页✨
                </button>
            </a>
        </div>

        <!-- 统计按钮 -->
        <a href="statistics" style="text-decoration: none;">
            <button class="btn-statistics">
                <i class="fas fa-chart-bar"></i> 统计📊
            </button>
        </a>
    </header>

    <c:if test="${not empty error}">
        <div class="error">
            <i class="fas fa-exclamation-circle"></i> ${error}
        </div>
    </c:if>

    <!-- 借书表单 -->
    <div class="card">
        <h2><i class="fas fa-plus-circle"></i> 新增借阅💓</h2>
        <form method="post" action="borrow">
            <input type="hidden" name="action" value="borrow">
            <div class="form-group">
                <label for="userId"><i class="fas fa-user"></i> 用户ID</label>
                <input type="number" id="userId" name="userId" required min="1" placeholder="请输入用户ID✨">
            </div>
            <div class="form-group">
                <label for="bookId"><i class="fas fa-book"></i> 图书ID</label>
                <input type="number" id="bookId" name="bookId" required min="1" placeholder="请输入图书ID✨">
            </div>
            <button type="submit">
                <i class="fas fa-bookmark"></i> 确认借书🎈
            </button>
        </form>
    </div>

    <!-- 查询与列表 -->
    <div class="card">
        <h2><i class="fas fa-list"></i> 借阅记录📝</h2>
        <form method="get" action="borrow" class="search-form">
            <input type="hidden" name="action" value="list">
            <input type="text" name="keyword" placeholder="🔍 学号或书名关键词✨" value="${keyword}">
            <button type="submit"><i class="fas fa-search"></i> 搜索🔎</button>
            <a href="borrow" style="text-decoration: none;">
                <button type="button" class="btn-refresh"><i class="fas fa-sync"></i> 刷新♻️</button>
            </a>
        </form>

        <table>
            <thead>
            <tr>
                <th>记录ID✨</th>
                <th>学号💖</th>
                <th>姓名🥰</th>
                <th>书名📚</th>
                <th>作者✍️</th>
                <th>借书时间⏰</th>
                <th>归还时间🔙</th>
                <th>状态📌</th>
                <th>操作🎈</th>
            </tr>
            </thead>
            <tbody>
            <c:forEach items="${records}" var="r">
                <tr>
                    <td>${r.recordId}</td>
                    <td>${r.studentId}</td>
                    <td>${r.username}</td>
                    <td>${r.bookTitle}</td>
                    <td>${r.author}</td>
                    <td>${r.borrowDate}</td>
                    <td>${r.returnDate == null ? '—' : r.returnDate}</td>
                    <td>
                        <c:choose>
                            <c:when test="${r.status == 'borrowed'}">
                                <span class="status-borrowed"><i class="fas fa-clock"></i> 未归还</span>
                            </c:when>
                            <c:when test="${r.status == 'overdue'}">
                                <span class="status-overdue"><i class="fas fa-exclamation-triangle"></i> 逾期</span>
                            </c:when>
                            <c:otherwise>
                                <span class="status-returned"><i class="fas fa-check-circle"></i> 已归还</span>
                            </c:otherwise>
                        </c:choose>
                    </td>
                    <td class="actions">
                        <c:if test="${r.status == 'borrowed'}">
                            <form method="post" action="borrow" style="display:inline;">
                                <input type="hidden" name="action" value="return">
                                <input type="hidden" name="recordId" value="${r.recordId}">
                                <button type="submit" class="btn-return" onclick="return confirm('确认归还《${r.bookTitle}》？💖')">
                                    <i class="fas fa-undo"></i> 还书
                                </button>
                            </form>
                        </c:if>
                        <form method="post" action="borrow" style="display:inline;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="recordId" value="${r.recordId}">
                            <button type="submit" class="btn-delete" onclick="return confirm('⚠️ 真的要删除此借阅记录吗？💔')">
                                <i class="fas fa-trash"></i> 删除
                            </button>
                        </form>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</div>

<script>
    // 提交按钮加载效果
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', () => {
            const btn = form.querySelector('button[type="submit"]');
            if (btn) btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 处理中...✨';
        });
    });
</script>
</body>
</html>