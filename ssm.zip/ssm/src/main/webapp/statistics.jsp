<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🎀 借阅统计中心 · 永无Bug队</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        :root {
            /* 可爱粉色主题配色 */
            --primary: #db2777;      /* 玫粉色（主色）- 保证可读性 */
            --primary-light: #ec4899;/* 浅玫粉 */
            --primary-bg: #fef7fb;   /* 粉色背景底 */
            --success: #10b981;      /* 清新绿 */
            --warning: #f59e0b;      /* 奶黄色 */
            --danger: #ef4444;       /* 珊瑚红 */
            --dark: #374151;         /* 深灰色（正文色） */
            --gray: #9ca3af;
            --card-bg: #ffffff;
            --shadow: 0 8px 24px rgba(219, 39, 119, 0.1);
            --shadow-hover: 0 12px 28px rgba(219, 39, 119, 0.15);
            --radius: 20px;          /* 圆润大圆角 */
            --small-radius: 12px;
        }

        @media (prefers-color-scheme: dark) {
            :root {
                --dark: #f8f9fa;
                --primary-bg: #2c1e2e;
                --card-bg: #1e1e2e;
                --gray: #a0a0a0;
                --shadow: 0 4px 12px rgba(0,0,0,0.3);
            }
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            /* 粉色波点背景，和其他页面统一 */
            background-color: var(--primary-bg);
            background-image:
                    radial-gradient(var(--primary-light) 0.5px, transparent 0.5px),
                    radial-gradient(var(--primary-light) 0.5px, var(--primary-bg) 0.5px);
            background-size: 20px 20px;
            background-position: 0 0, 10px 10px;
            color: var(--dark);
            min-height: 100vh;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        header {
            margin-bottom: 30px;
            padding: 20px 0;
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .header-title {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        h1 {
            font-size: 2.5rem;
            /* 粉色渐变文字 */
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            font-weight: 800;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .subtitle {
            color: var(--primary);
            margin-left: 10px;
            font-size: 1.1rem;
            font-weight: 500;
        }

        .error {
            background: #ffebee;
            color: var(--primary);
            padding: 12px 20px;
            border-radius: var(--small-radius);
            margin-bottom: 24px;
            display: inline-block;
            box-shadow: var(--shadow);
            animation: fadeIn 0.5s ease;
            border-left: 4px solid var(--primary);
        }

        /* 统计卡片样式（可爱化） */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 24px;
            text-align: center;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            border: 1px solid #fce7f3;
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 6px;
            background: linear-gradient(90deg, var(--primary), var(--primary-light));
        }

        .stat-card.overdue::before {
            background: linear-gradient(90deg, var(--danger), #f87171);
        }

        .stat-card.current::before {
            background: linear-gradient(90deg, var(--warning), #fbbf24);
        }

        .stat-card:hover {
            transform: translateY(-6px);
            box-shadow: var(--shadow-hover);
        }

        .stat-icon {
            font-size: 1.8rem;
            color: var(--primary);
            margin-bottom: 12px;
        }

        .stat-card.overdue .stat-icon {
            color: var(--danger);
        }

        .stat-card.current .stat-icon {
            color: var(--warning);
        }

        .stat-label {
            font-size: 1.1rem;
            color: var(--dark);
            font-weight: 500;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 800;
            margin: 10px 0;
            color: var(--primary);
            text-shadow: 0 2px 4px rgba(219, 39, 119, 0.1);
        }

        .stat-card.overdue .stat-value {
            color: var(--danger);
        }

        .stat-card.current .stat-value {
            color: var(--warning);
        }

        .stat-unit {
            font-size: 1rem;
            color: var(--gray);
            font-weight: 500;
        }

        /* 卡片样式统一 */
        .card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 24px;
            margin-bottom: 30px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            border: 1px solid #fce7f3;
        }

        .card:hover {
            transform: translateY(-4px);
            box-shadow: var(--shadow-hover);
        }

        .card h2 {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            color: var(--primary);
            font-size: 1.4rem;
        }

        /* 表格样式 */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: var(--card-bg);
            border-radius: var(--small-radius);
            overflow: hidden;
        }

        th, td {
            padding: 14px;
            text-align: left;
            border-bottom: 1px solid #fce7f3;
        }

        th {
            background: rgba(219, 39, 119, 0.08);
            font-weight: 600;
            color: var(--primary);
        }

        tr:hover {
            background: rgba(219, 39, 119, 0.05);
        }

        .rank-number {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            background: var(--primary-bg);
            color: var(--primary);
            border-radius: 50%;
            font-weight: bold;
        }

        .borrow-count {
            color: var(--primary);
            font-weight: bold;
        }

        /* 首页按钮样式 */
        .btn-home {
            background: white;
            color: var(--primary);
            border: 2px solid #fce7f3;
            padding: 10px 18px;
            border-radius: var(--small-radius);
            cursor: pointer;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
        }

        .btn-home:hover {
            background: var(--primary-bg);
            transform: scale(1.03);
        }

        /* 统计链接样式 */
        .stats-link {
            color: var(--primary);
            font-size: 1.1rem;
            font-weight: 500;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }

        .stats-link:hover {
            color: var(--primary-light);
            transform: translateX(5px);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
            }
            th, td {
                padding: 10px 8px;
                font-size: 0.9rem;
            }
            h1 {
                font-size: 2rem;
            }
            .header-top {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <header>
        <div class="header-top">
            <div class="header-title">
                <h1><i class="fas fa-chart-bar"></i> 借阅统计中心🎀</h1>
                <p class="subtitle">永无Bug队 · 张负责💖</p>
            </div>
            <a href="index.jsp" class="btn-home">
                <i class="fas fa-home"></i> 首页✨
            </a>
        </div>
    </header>

    <a href="statistics" class="stats-link"><i class="fas fa-chart-pie"></i> 📊 借阅统计</a>

    <c:if test="${not empty error}">
        <div class="error">
            <i class="fas fa-exclamation-circle"></i> ${error}
        </div>
    </c:if>

    <!-- 统计卡片 -->
    <div class="stats-grid">
        <div class="stat-card current">
            <div class="stat-icon"><i class="fas fa-book-open"></i></div>
            <div class="stat-label">当前借阅中📖</div>
            <div class="stat-value">${currentBorrowCount}</div>
            <div class="stat-unit">本</div>
        </div>
        <div class="stat-card overdue">
            <div class="stat-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="stat-label">逾期未还⚠️</div>
            <div class="stat-value">${overdueCount}</div>
            <div class="stat-unit">本</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-trophy"></i></div>
            <div class="stat-label">热门图书🏆</div>
            <div class="stat-value">${topBooks.size()}</div>
            <div class="stat-unit">种（Top 10）</div>
        </div>
    </div>

    <!-- Top 10 图书表格 -->
    <div class="card">
        <h2><i class="fas fa-fire"></i> 借阅排行榜（Top 10）🔥</h2>
        <table>
            <thead>
            <tr>
                <th>排名🥇</th>
                <th>书名📚</th>
                <th>作者✍️</th>
                <th>借阅次数🎈</th>
            </tr>
            </thead>
            <tbody>
            <c:forEach items="${topBooks}" var="book" varStatus="status">
                <tr>
                    <td><span class="rank-number">${status.index + 1}</span></td>
                    <td>${book.title}</td>
                    <td>${book.author}</td>
                    <td><span class="borrow-count">${book.borrowCount} 次</span></td>
                </tr>
            </c:forEach>
            <c:if test="${empty topBooks}">
                <tr>
                    <td colspan="4" style="text-align: center; color: var(--primary); padding: 20px;">
                        <i class="fas fa-book-heart"></i> 暂无借阅数据💔
                    </td>
                </tr>
            </c:if>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>